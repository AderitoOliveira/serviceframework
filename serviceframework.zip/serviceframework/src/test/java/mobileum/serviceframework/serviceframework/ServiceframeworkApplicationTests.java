package mobileum.serviceframework.serviceframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceframeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}

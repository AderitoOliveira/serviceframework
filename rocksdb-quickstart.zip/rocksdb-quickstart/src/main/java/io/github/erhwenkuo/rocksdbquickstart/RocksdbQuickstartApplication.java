package io.github.erhwenkuo.rocksdbquickstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RocksdbQuickstartApplication {

	public static void main(String[] args) {
		SpringApplication.run(RocksdbQuickstartApplication.class, args);
	}

}

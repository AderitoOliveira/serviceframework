package io.github.erhwenkuo.rocksdbquickstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RocksdbQuickstartApplicationTests {

	@Test
	void contextLoads() {
	}

}
